/*public class Review extends Student
{
  private final String review;
  
  public Review (String title, int id, boolean onLoan, String targetDate, String lesson, String type) {
      super( fisrtName, gender, DOB, address, 
          contactNumber, courses, toutionBalance, costOfCourse, 
          studentID, review, title);
      this.review = review;
  }
  
  public String getReview (){
      return review;
  }  
}*/