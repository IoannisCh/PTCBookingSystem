/*public class Attending extends Student
{
  private final String lesson;
  
  public Attending (String title, int id, boolean onLoan, String targetDate, String lesson, String type) {
      super( fisrtName, gender, DOB, address, 
          contactNumber, courses, toutionBalance, costOfCourse, 
          studentID, review, title);
      this.lesson = lesson;
  }
  
  public String getAttending (){
      return lesson;
  }
}*/