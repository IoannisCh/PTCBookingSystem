/*public class Book extends Student
{
  private final String author;
  
  public Book (String title, int id, boolean onLoan, String targetDate, String lesson, String type) {
      super( fisrtName, gender, DOB, address, 
          contactNumber, courses, toutionBalance, costOfCourse, 
          studentID, review, title);
      this.author = author;
  }
  
  public String getAuthor (){
      return author;
  }
}*/